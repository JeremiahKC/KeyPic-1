package com.kcassets.keypic;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PhotoActivity extends AppCompatActivity {


    /***********************************************************
     * Initializations
     **********************************************************/
    Spinner typeSpinner;
    Spinner phaseSpinner;
    Spinner unitSpinner;
    ListView photoList;
    EditText job;
    ImageView check;
    Button photoBtn, folderBtn;
    String folderName;
    List<String> fileNames = new ArrayList<>();
    List<String> existingFileNames = new ArrayList<>();
    private static final int CAMERA_REQUEST_CODE = 123;
    private Drive driveService;
    String accessToken;

    // Arrays
    String[] typeArray;
    String[] phaseArray;
    String[] unitArray;
    private String selectedType;
    private String selectedPhase;
    private String selectedUnit;
    private ArrayAdapter<String> listAdapter;
    private String[] selectedArray;


    /***********************************************************
     * onCreate
     **********************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.photo_screen);


        /***********************************************************
         * Local Initializations
         **********************************************************/
        // Initialize spinners and list view and buttons
        typeSpinner = findViewById(R.id.typeSpinner);
        phaseSpinner = findViewById(R.id.phaseSpinner);
        unitSpinner = findViewById(R.id.unitSpinner);
        photoList = findViewById(R.id.photoList);
        photoBtn = findViewById(R.id.photoBtn);
        folderBtn = findViewById(R.id.folderBtn);
        job = findViewById(R.id.job);
        check = findViewById(R.id.check);

        check.setVisibility(View.INVISIBLE);

        // Initialize arrays from resources
        typeArray = getResources().getStringArray(R.array.amazon_type);
        phaseArray = getResources().getStringArray(R.array.amazon_phase);
        unitArray = getResources().getStringArray(R.array.amazon_unit);

        // Setup Spinners
        setupSpinners();

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        accessToken = sharedPreferences.getString("access_token", null);
        Log.d("ConfirmActivity", "Access Token: " + accessToken);


        /***********************************************************
         * Buttons
         **********************************************************/
        photoBtn.setOnClickListener(v -> {
            makePhotoList();
        });

        // Set click listener for photo list items
        photoList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (folderName != null){
                    // Get the selected photo name
                    String selectedPhoto = (String) parent.getItemAtPosition(position);
                    String selectedFileName = fileNames.get(position);
                    // Call the launchCamera method or perform desired action
                    launchCamera(selectedPhoto, selectedFileName, folderName);
                } else {
                    Toast.makeText(PhotoActivity.this, "Error: Job Number/Folder is empty or invalid", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Get reference to the parent layout of your activity
        RelativeLayout parentLayout = findViewById(R.id.photoLayout);

        // Set an OnTouchListener for the parent layout
        parentLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Close the keyboard
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(job.getWindowToken(), 0);

                // Remove focus and cursor from the EditText
                job.clearFocus();

                // Return false to allow other touch events to be processed
                return false;
            }
        });

        job.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Set the visibility of 'check' to GONE
                check.setVisibility(View.GONE);
                return false;
            }
        });


        /***********************************************************
         * Google Drive Folder Check
         **********************************************************/
        HttpTransport httpTransport = new com.google.api.client.http.javanet.NetHttpTransport();
        JsonFactory jsonFactory = new com.google.api.client.json.jackson2.JacksonFactory();

        // Initialize Google Drive API client
        GoogleCredential credential = new GoogleCredential().setAccessToken(accessToken);
        driveService = new Drive.Builder(httpTransport, jsonFactory, credential)
                .setApplicationName("KeyPic")
                .build();

        // Set click listener for the search/create button
        folderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the folder name from the EditText
                folderName = job.getText().toString();

                ProgressDialog progressDialog = new ProgressDialog(PhotoActivity.this);
                progressDialog.setIndeterminate(true);
                progressDialog.setCancelable(false);

                // Close the keyboard
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(job.getWindowToken(), 0);

                // Remove focus and cursor from the EditText
                job.clearFocus();

                // Perform the Google Drive API task
                DriveTask driveTask = new DriveTask(folderName, driveService, progressDialog);
                driveTask.execute();
            }
        });
    }


    /***********************************************************
     * Spinner Setup
     **********************************************************/
    private void setupSpinners() {
        // Set adapters for spinners
        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, typeArray);
        typeSpinner.setAdapter(typeAdapter);

        ArrayAdapter<String> phaseAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, phaseArray);
        phaseSpinner.setAdapter(phaseAdapter);

        ArrayAdapter<String> unitAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, unitArray);
        unitSpinner.setAdapter(unitAdapter);
    }


    /***********************************************************
     * Photo List Creation
     **********************************************************/
    private void makePhotoList() {
        // Get selected spinner values
        selectedType = typeSpinner.getSelectedItem().toString();
        selectedPhase = phaseSpinner.getSelectedItem().toString();
        selectedUnit = unitSpinner.getSelectedItem().toString();

        // Create an array name based on the selected values
        String arrayName = selectedType + "_" + selectedPhase + "_" + selectedUnit;

        // Get the resource ID of the array dynamically
        int arrayId = getResources().getIdentifier(arrayName, "array", getPackageName());

        // Populate the list view with the selected array
        String[] selectedArray = new String[0];
        if (arrayId != 0) {
            selectedArray = getResources().getStringArray(arrayId);
            listAdapter = new ArrayAdapter<>(PhotoActivity.this, android.R.layout.simple_list_item_1, selectedArray);
            photoList.setAdapter(listAdapter);
        }

        fileNames.clear();

        // Get the resource ID of the file name array dynamically
        int fileNameArrayId = getResources().getIdentifier(arrayName + "_File", "array", getPackageName());

        // Retrieve the string array of file names using the resource ID
        String[] fileNameArray = getResources().getStringArray(fileNameArrayId);

        // Match each item in the ListView array with the corresponding file name using their positions in the arrays
        List<String> listViewItems = Arrays.asList(selectedArray);

        for (int i = 0; i < listViewItems.size(); i++) {
            String listViewItem = listViewItems.get(i);
            String fileName = fileNameArray[i];
            fileNames.add(fileName);
        }

        // Compare this list to the fileNames list above
        photoList.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                // Remove the listener to avoid multiple calls
                photoList.getViewTreeObserver().removeOnGlobalLayoutListener(this);

                for (int i = 0; i < fileNames.size(); i++) {
                    String fileName = fileNames.get(i);
                    if (existingFileNames.contains(fileName)) {
                        // Call a method that highlights the corresponding photo name item in the photoList to green
                        highlightPhotoNameItem(i);
                    }
                }
            }
        });
    }

    private void highlightPhotoNameItem(int position) {
        // Check if the position is valid and the item is visible
        if (position >= 0 && position < photoList.getChildCount()) {
            Log.e("PhotoActivity", "position highlighted: " + position);
            // Get the View corresponding to the specified position in the photoList
            View itemView = photoList.getChildAt(position);

            // Apply the highlighting effect to the itemView (e.g., change the text color to green)
            itemView.setBackgroundColor(Color.GREEN);
        }
    }


    /***********************************************************
     * Camera Activity Launcher
     **********************************************************/
    private void launchCamera(String photoName, String fileName, String folderName) {
        Intent intent = new Intent(this, CameraLaunchActivity.class);
        intent.putExtra("photoName", photoName);
        intent.putExtra("fileName", fileName);
        intent.putExtra("folderName", folderName);
        intent.putExtra("selectedType", selectedType);
        intent.putExtra("selectedPhase", selectedPhase);
        intent.putExtra("selectedUnit", selectedUnit);
        startActivityForResult(intent, CAMERA_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST_CODE && (resultCode == RESULT_OK || resultCode == RESULT_CANCELED)) {
            // Restore the state of the activity
            if (data != null) {
                selectedType = data.getStringExtra("selectedType");
                selectedPhase = data.getStringExtra("selectedPhase");
                selectedUnit = data.getStringExtra("selectedUnit");

                // Set the spinner values
                typeSpinner.setSelection(getIndex(typeArray, selectedType));
                phaseSpinner.setSelection(getIndex(phaseArray, selectedPhase));
                unitSpinner.setSelection(getIndex(unitArray, selectedUnit));

                // Restore the generated list
                if (selectedArray != null && listAdapter != null) {
                    listAdapter.clear();
                    listAdapter.addAll(selectedArray);
                }
            }
        }
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
            Toast.makeText(PhotoActivity.this, "Photo Saved Successfully in Drive", Toast.LENGTH_SHORT).show();
            String savedPhoto = getIntent().getStringExtra("photoName");
            int i = listAdapter.getPosition(savedPhoto);
            highlightPhotoNameItem(i);
        }
    }

    private int getIndex(String[] array, String value) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].equals(value)) {
                return i;
            }
        }
        return -1;
    }


    /***********************************************************
     * Folder Check and Creation
     **********************************************************/
    public class DriveTask extends AsyncTask<String, Void, Void> {
        private String folderName;
        private Drive service;
        private ProgressDialog progressDialog;
        private boolean createFolder;

        public DriveTask(String folderName, Drive service, ProgressDialog progressDialog) {
            this.folderName = folderName;
            this.service = service;
            this.progressDialog = progressDialog;
            this.createFolder = false;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Searching folder...");
            progressDialog.show();
        }

        @Override
        protected Void doInBackground(String... params) {
            try {
                // Search for the folder by name
                String query = "mimeType='application/vnd.google-apps.folder' and name='" + folderName + "'";
                FileList result = service.files().list().setQ(query).setSpaces("drive").execute();
                List<File> files = result.getFiles();

                // Check if the folder exists
                if (files != null && !files.isEmpty()) {
                    // Folder exists
                    File folder = files.get(0);
                    System.out.println("Folder already exists: " + folder.getName());

                    // Gather file names that exist in that folder and add them to a list
                    String folderId = folder.getId();
                    String fileQuery = "'" + folderId + "' in parents and trashed=false";
                    FileList fileList = service.files().list().setQ(fileQuery).setSpaces("drive").execute();
                    List<File> folderFiles = fileList.getFiles();
                    existingFileNames.clear();
                    for (File file : folderFiles) {
                        existingFileNames.add(file.getName());
                    }

                } else {
                    // Folder does not exist
                    createFolder = true;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            progressDialog.dismiss();
            if (!createFolder) {
                check.setVisibility(View.VISIBLE);
                Toast.makeText(PhotoActivity.this, "Folder Found in 'My Drive'", Toast.LENGTH_SHORT).show();
                if (!fileNames.isEmpty()) {
                    makePhotoList();
                }
            }

            if (createFolder) {
                showCreateFolderDialog();
            }
        }

        private void showCreateFolderDialog() {
            AlertDialog.Builder builder = new AlertDialog.Builder(progressDialog.getContext());
            builder.setMessage("This folder does not exist. Would you like to create it?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            createFolder();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // Cancel the task and do not create the folder
                        }
                    });

            AlertDialog alert = builder.create();
            alert.show();
        }

        private void createFolder() {
            ProgressDialog createFolderProgressDialog = new ProgressDialog(PhotoActivity.this);
            createFolderProgressDialog.setCancelable(false);

            new CreateFolderTask(folderName, service, createFolderProgressDialog).execute();
        }

        private class CreateFolderTask extends AsyncTask<Void, Void, Void> {
            private String folderName;
            private Drive service;
            private ProgressDialog progressDialog;

            public CreateFolderTask(String folderName, Drive service, ProgressDialog progressDialog) {
                this.folderName = folderName;
                this.service = service;
                this.progressDialog = progressDialog;
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog.setMessage("Creating folder...");
                progressDialog.show();
            }

            @Override
            protected Void doInBackground(Void... params) {
                try {
                    File folderMetadata = new File();
                    folderMetadata.setName(folderName);
                    folderMetadata.setMimeType("application/vnd.google-apps.folder");

                    File folder = service.files().create(folderMetadata).setFields("id").execute();
                    System.out.println("Folder created: " + folder.getName() + " (ID: " + folder.getId() + ")");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                super.onPostExecute(result);
                progressDialog.dismiss();
                if (listAdapter != null) {
                    List<String> emptyList = new ArrayList<>(); // Create an empty list
                    listAdapter = new ArrayAdapter<>(PhotoActivity.this, android.R.layout.simple_list_item_1, emptyList);
                    photoList.setAdapter(listAdapter);
                }
                existingFileNames.clear();
                check.setVisibility(View.VISIBLE);
                Toast.makeText(PhotoActivity.this, "Folder Created in 'My Drive'", Toast.LENGTH_SHORT).show();
                // Handle any post-create folder operations or UI updates
            }
        }
    }
}
